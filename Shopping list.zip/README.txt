Shopping list for fruit salad

-I recommend to use codepen.io to run this project
-You can run this project by using only javascript. HTML and CSS are just for styling.
-There should appear two boxes. First box will ask ingredient and the second one price of that product.
-When you are ready with the list just press the cancel.
-After that you will see the sorted in your console. This project sorts products from cheapeast to most expensive.